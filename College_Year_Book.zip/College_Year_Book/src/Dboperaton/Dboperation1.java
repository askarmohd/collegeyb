package Dboperaton;
import java.util.List; 
import org.hibernate.*; 
import org.hibernate.cfg.Configuration;

import bean.Student;
import bean.Teacher; 
public class Dboperation1 {
	SessionFactory sf;  
	Session s;  
	Transaction tx; 
	 

	public Dboperation1() {
		// TODO Auto-generated constructor stub
		sf=new Configuration().configure("hibernate1.cfg.xml").buildSessionFactory(); 
	}
	
	public String insert(Teacher tea)  {   
		String result=null;  
		s=sf.openSession();  
		tx=s.beginTransaction();  
		try 
	  {    
			s.saveOrUpdate(tea);    
			tx.commit();  
			s.close();    
			result="value inserted";   
			}  
		catch(Exception e) 
		{    
			result="error at insert";   
			}   
		
		return result; 
		}
	
	 
}
