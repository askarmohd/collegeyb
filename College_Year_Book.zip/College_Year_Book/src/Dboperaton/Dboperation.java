package Dboperaton;
import java.util.List; 
import org.hibernate.*; 
import org.hibernate.cfg.Configuration;

import bean.Student;
import bean.Teacher; 
public class Dboperation {
	SessionFactory sf;  
	Session s;  
	Transaction tx; 
	 

	public Dboperation() {
		// TODO Auto-generated constructor stub
		sf=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory(); 
	}
	public String insert(Student stu)  {   
		String result=null;  
		s=sf.openSession();  
		tx=s.beginTransaction();  
		try 
	  {    
			s.saveOrUpdate(stu);    
			tx.commit();  
			s.close();    
			result="value inserted";   
			}  
		catch(Exception e) 
		{    
			result="error at insert";   
			}   
		
		return result; 
		}
	
	
	 
}
