package Service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dboperaton.Dboperation;
import Dboperaton.Dboperation1;
import bean.Student;
import bean.Teacher;

import java.io.*;
import java.util.List;
import javax.servlet.*; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.*; 
@WebServlet("/Studentser")
public class Teacherser extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		PrintWriter out=response.getWriter();   
		response.setContentType("text/html");     
		
		int tid=Integer.parseInt(request.getParameter("tid"));   
		String tname=request.getParameter("tname"); 
		String mail1=request.getParameter("mail1"); 
		String pass1=request.getParameter("pass1");
		     
		
		Teacher tea=new Teacher();   
		tea.setTid(tid);  
		tea.setTname(tname); 
		tea.setMail1(mail1);
		tea.setPass1(pass1);
		Dboperation1 db=new Dboperation1();  
		
		out.println(db.insert(tea));
		
	}
 
}
