package Service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dboperaton.Dboperation;
import bean.Student;
import bean.Teacher;

import java.io.*;
import java.util.List;
import javax.servlet.*; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.*; 
@WebServlet("/Studentser")
public class Studentser extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		PrintWriter out=response.getWriter();   
		response.setContentType("text/html");     
		int sid=Integer.parseInt(request.getParameter("sid"));
		
		String sname=request.getParameter("sname"); 
		String mail=request.getParameter("mail"); 
		String pass=request.getParameter("pass");
		
		     
		Student stu=new Student();   
		stu.setSid(sid);  
		stu.setSname(sname); 
		stu.setMail(mail);
		stu.setPass(pass);
		
		Dboperation db=new Dboperation();  
		out.println(db.insert(stu));
		
		
	}
 
}
